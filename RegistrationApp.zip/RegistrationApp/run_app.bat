@echo off
setlocal
cd /d "%~dp0"
title Event Registration App - Build and Launch

rem ---- locate Android SDK ----
if not defined ANDROID_HOME set "ANDROID_HOME=%LOCALAPPDATA%\Android\Sdk"
if not exist "%ANDROID_HOME%\platform-tools\adb.exe" (
  echo Android SDK not found at %ANDROID_HOME%
  echo Install Android Studio, or set ANDROID_HOME to your SDK folder.
  pause & exit /b 1
)
set "SDKDIR=%ANDROID_HOME:\=/%"
echo sdk.dir=%SDKDIR%> local.properties

rem ---- use Android Studio's bundled JDK if JAVA_HOME is not set ----
if not defined JAVA_HOME (
  if exist "%ProgramFiles%\Android\Android Studio\jbr\bin\java.exe" set "JAVA_HOME=%ProgramFiles%\Android\Android Studio\jbr"
)

echo Checking for a device or emulator...
"%ANDROID_HOME%\platform-tools\adb.exe" start-server >nul 2>&1
"%ANDROID_HOME%\platform-tools\adb.exe" devices | findstr /R /C:"	device$" >nul
if errorlevel 1 (
  echo No device found. Start an emulator in Android Studio or plug in a phone with USB debugging, then run again.
  pause & exit /b 1
)

echo Building and installing...
call gradlew.bat installDebug
if errorlevel 1 ( echo Build failed. & pause & exit /b 1 )

echo Launching app...
"%ANDROID_HOME%\platform-tools\adb.exe" shell am start -n com.example.registration/.MainActivity
echo Done.
pause
