# Event Registration App (Android, Java)

Registration screen for a college cultural fest: welcome message, name and email fields,
terms checkbox and a Register button. On Register the entered details are shown on screen.

## Features
- Custom font: Poppins (Bold + Regular) in `res/font`
- Several text sizes: 32sp title, 16sp fields, 14sp body, 11sp labels
- Colours: indigo gradient background, white card, amber button (`res/values/colors.xml`)
- Validation: name required, valid email, terms must be ticked

## Run
1. Android Studio: File > Open > this folder, wait for Gradle sync, press Run.
2. Or start an emulator / connect a phone, then double-click `run_app.bat`.

Needs JDK 17 (bundled with Android Studio), Android SDK 34 and internet for the first build.
