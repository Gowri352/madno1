package com.example.registration;

import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private EditText etName, etEmail;
    private CheckBox cbTerms;
    private LinearLayout resultBox;
    private TextView tvResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etEmail = findViewById(R.id.etEmail);
        cbTerms = findViewById(R.id.cbTerms);
        resultBox = findViewById(R.id.resultBox);
        tvResult = findViewById(R.id.tvResult);
        Button btnRegister = findViewById(R.id.btnRegister);

        btnRegister.setOnClickListener(v -> register());
    }

    private void register() {
        String name = etName.getText().toString().trim();
        String email = etEmail.getText().toString().trim();

        if (name.isEmpty()) {
            etName.setError("Please enter your name");
            etName.requestFocus();
            return;
        }
        if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            etEmail.setError("Please enter a valid email");
            etEmail.requestFocus();
            return;
        }
        if (!cbTerms.isChecked()) {
            Toast.makeText(this, "Please accept the terms and conditions",
                    Toast.LENGTH_SHORT).show();
            return;
        }

        tvResult.setText("Name:  " + name + "\nEmail:  " + email
                + "\nTerms:  Accepted");
        resultBox.setVisibility(View.VISIBLE);
        Toast.makeText(this, "Registered successfully, " + name + "!",
                Toast.LENGTH_LONG).show();
    }
}
